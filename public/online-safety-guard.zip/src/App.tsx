/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { MessageScanner } from './components/MessageScanner';
import { AnalysisReport } from './components/AnalysisReport';
import { DomainChecker } from './components/DomainChecker';
import { RedFlagQuiz } from './components/RedFlagQuiz';
import { EmergencyGuide } from './components/EmergencyGuide';
import { ScanHistoryView } from './components/ScanHistoryView';
import { AnalysisResult } from './types';
import { getScanHistory, saveScanToHistory, clearScanHistory } from './utils/storage';
import { ShieldCheck, ShieldAlert, Sparkles, Lock, ExternalLink, Download } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'scanner' | 'domain' | 'quiz' | 'emergency' | 'history'>('scanner');
  const [currentAnalysis, setCurrentAnalysis] = useState<AnalysisResult | null>(null);
  const [history, setHistory] = useState<AnalysisResult[]>([]);
  
  // Theme state: default to 'light' to immediately showcase the requested watermark image
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('online_guard_theme');
      if (saved === 'dark' || saved === 'light') return saved;
      // Default to light mode so the watermark is immediately prominent as requested
      return 'light';
    }
    return 'light';
  });

  // Watermark intensity state for light mode: 'subtle' (15%), 'balanced' (28%), 'vivid' (45%)
  const [watermarkIntensity, setWatermarkIntensity] = useState<'subtle' | 'balanced' | 'vivid'>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('watermark_intensity');
      if (saved === 'subtle' || saved === 'balanced' || saved === 'vivid') return saved;
    }
    return 'balanced';
  });

  // Keep <html> element in sync with dark mode
  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('online_guard_theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme(prev => (prev === 'light' ? 'dark' : 'light'));
  };

  const cycleWatermarkIntensity = () => {
    const next = watermarkIntensity === 'subtle' ? 'balanced' : watermarkIntensity === 'balanced' ? 'vivid' : 'subtle';
    setWatermarkIntensity(next);
    localStorage.setItem('watermark_intensity', next);
  };

  const watermarkOpacityValue = {
    subtle: 0.16,
    balanced: 0.28,
    vivid: 0.42,
  }[watermarkIntensity];

  useEffect(() => {
    setHistory(getScanHistory());
  }, []);

  const handleAnalysisComplete = (result: AnalysisResult) => {
    setCurrentAnalysis(result);
    saveScanToHistory(result);
    setHistory(getScanHistory());
    setActiveTab('scanner');
    // Scroll to top of report
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleClearHistory = () => {
    clearScanHistory();
    setHistory([]);
  };

  const handleSelectFromHistory = (scan: AnalysisResult) => {
    setCurrentAnalysis(scan);
    setActiveTab('scanner');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className={`min-h-screen flex flex-col relative transition-colors duration-200 selection:bg-rose-500 selection:text-white ${
      theme === 'dark' ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-900'
    }`}>
      {/* Light Mode Cyber Security Watermark Background */}
      {theme === 'light' && (
        <div 
          className="fixed inset-0 pointer-events-none z-0 overflow-hidden select-none transition-opacity duration-500"
          style={{ opacity: watermarkOpacityValue }}
          aria-hidden="true"
        >
          {/* Wallpaper Image Watermark */}
          <img
            src="/cyber_security_bg.jpg"
            alt="Cyber Security Watermark"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-center mix-blend-multiply filter contrast-110 saturate-125"
          />
          {/* Subtle light vignette overlay to ensure pristine accessibility and high text contrast */}
          <div className="absolute inset-0 bg-gradient-to-b from-slate-50/40 via-transparent to-slate-50/70" />
        </div>
      )}

      {/* Dark Mode subtle cyber ambient background */}
      {theme === 'dark' && (
        <div 
          className="fixed inset-0 pointer-events-none z-0 overflow-hidden select-none opacity-20"
          aria-hidden="true"
        >
          <img
            src="/cyber_security_bg.jpg"
            alt=""
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-center filter contrast-125 brightness-75"
          />
          <div className="absolute inset-0 bg-slate-950/75" />
        </div>
      )}

      {/* App Header */}
      <Header
        activeTab={activeTab}
        onSelectTab={(tab) => {
          setActiveTab(tab);
          if (tab !== 'scanner') {
            // keep currentAnalysis in state so user can return to it if they want
          }
        }}
        historyCount={history.length}
        theme={theme}
        onToggleTheme={toggleTheme}
        watermarkIntensity={watermarkIntensity}
        onCycleWatermark={cycleWatermarkIntensity}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-6xl w-full mx-auto px-4 sm:px-6 py-6 sm:py-8 relative z-10">
        {activeTab === 'scanner' && (
          <>
            {currentAnalysis ? (
              <AnalysisReport
                result={currentAnalysis}
                onScanAnother={() => setCurrentAnalysis(null)}
              />
            ) : (
              <div className="space-y-6">
                {/* Hero Banner */}
                <div className="text-center max-w-2xl mx-auto space-y-2.5 pb-2">
                  <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-500/10 border border-rose-500/25 text-rose-700 dark:text-rose-400 text-xs font-semibold shadow-xs">
                    <ShieldAlert className="w-3.5 h-3.5" />
                    <span>Real-time Scam, Smishing & Phishing Shield</span>
                  </div>
                  <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 dark:text-white">
                    Check Any Suspicious Message or DM
                  </h2>
                  <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
                    Paste an unexpected text, email, or social media message to detect deceptive links, urgent psychological pressure, and brand impersonation.
                  </p>
                </div>

                <MessageScanner onAnalysisComplete={handleAnalysisComplete} />
              </div>
            )}
          </>
        )}

        {activeTab === 'domain' && <DomainChecker />}

        {activeTab === 'quiz' && <RedFlagQuiz />}

        {activeTab === 'emergency' && <EmergencyGuide />}

        {activeTab === 'history' && (
          <ScanHistoryView
            history={history}
            onSelectScan={handleSelectFromHistory}
            onClearHistory={handleClearHistory}
            onNewScan={() => {
              setCurrentAnalysis(null);
              setActiveTab('scanner');
            }}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-200/80 dark:border-slate-800/90 bg-white/70 dark:bg-slate-950/90 backdrop-blur-md py-6 mt-12 relative z-10 transition-colors">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-600 dark:text-slate-400">
          <div className="flex items-center gap-2">
            <Lock className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400" />
            <span>Online Safety Guard — Privacy First: No message data is retained permanently.</span>
          </div>

          <div className="flex items-center gap-4 flex-wrap">
            <button
              onClick={() => setActiveTab('emergency')}
              className="hover:text-amber-600 dark:hover:text-amber-400 transition-colors font-medium cursor-pointer"
            >
              Emergency Advice
            </button>
            <span>•</span>
            <button
              onClick={() => setActiveTab('quiz')}
              className="hover:text-slate-900 dark:hover:text-slate-200 transition-colors font-medium cursor-pointer"
            >
              Scam Quiz
            </button>
            <span>•</span>
            <button
              onClick={() => setActiveTab('domain')}
              className="hover:text-slate-900 dark:hover:text-slate-200 transition-colors font-medium cursor-pointer"
            >
              Link Checker
            </button>
            <span>•</span>
            <a
              href="/online-safety-guard.zip"
              download="online-safety-guard.zip"
              className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-rose-500/10 hover:bg-rose-500/20 text-rose-700 dark:text-rose-400 font-semibold border border-rose-500/25 transition-colors cursor-pointer"
              title="Download clean project zip file"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export ZIP</span>
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}
