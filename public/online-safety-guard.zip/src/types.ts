export type SafetyStatus = 'SAFE' | 'SUSPICIOUS' | 'DANGEROUS_SCAM';

export interface RedFlag {
  flag: string;
  evidence: string;
  severity: 'high' | 'medium' | 'low';
}

export interface HighlightPhrase {
  text: string;
  category: 'danger' | 'warning' | 'suspicious_link';
  explanation: string;
}

export interface SafetyAdvice {
  immediateActions: string[];
  whatNeverToDo: string[];
  officialVerificationStep: string;
}

export interface SenderAssessment {
  isSenderSuspicious: boolean;
  notes: string;
}

export interface AnalysisResult {
  id: string;
  timestamp: string;
  originalMessage: string;
  sender?: string;
  platform?: string;
  safetyStatus: SafetyStatus;
  riskScore: number;
  scamType: string;
  verdictSummary: string;
  redFlags: RedFlag[];
  tacticsUsed: string[];
  highlightPhrases: HighlightPhrase[];
  safetyAdvice: SafetyAdvice;
  recommendedResponse: string;
  senderAssessment: SenderAssessment;
  engine?: string;
}

export interface PresetMessage {
  id: string;
  title: string;
  category: string;
  platform: string;
  sender: string;
  text: string;
  expectedRisk: 'SAFE' | 'DANGEROUS';
  badge: string;
}

export interface DomainInspectionResult {
  domain: string;
  fullUrl: string;
  isSuspicious: boolean;
  threatLevel: 'HIGH' | 'MEDIUM' | 'LOW';
  spoofedBrand?: string | null;
  reason: string;
  officialDomain?: string | null;
}
